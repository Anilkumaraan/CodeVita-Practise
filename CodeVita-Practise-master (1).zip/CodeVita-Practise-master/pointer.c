#include<stdio.h>
int main()
{
int a=10;
int *ptr;
ptr=&a;
printf("%d",a);
printf("%d",*ptr);
printf("\nHello");
return 0;
}
