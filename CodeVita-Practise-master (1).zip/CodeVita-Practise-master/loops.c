#include<stdio.h>
int main()
{
char i=1;
while(i++)
	printf("\nAscii of %c is %d",i,i);	
return 0;
}