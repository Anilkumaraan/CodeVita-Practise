#include<stdio.h>
#include<conio.h>
int main()
{
int n=5;
a=n%2;
printf("Ans : %d \n IF ans is Zero its even \n If ans is one its odd",a)
}