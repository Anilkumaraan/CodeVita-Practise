#include<stdio.h>
void add(int x,int y)
{
    printf("%d",x+y);
}
main()
{
    int a=10,b=5;
    add(a,b);
    return 0;
}
